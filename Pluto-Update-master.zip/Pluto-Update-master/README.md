<h1 align='center'>Online Shopping Store</h1>

- An Ecommerce website designed in HTML, CSS and PHP.

## About the Website

 - A Realtime Customer-Seller intraction ecommerce website that make it possible to create a virtual shopping environment for users such as Amazon.com.
- <b>Language and Technology: </b> PHP, HTML, CSS, JS & MySQL


- <b>Website link :</b>[Click here🎉](http://pluto-update.epizy.com/Pluto-Update-master/index.html)

- <b>Login Details: </b> 
- Username: Ana 
- Password: 786 

![](back_images/uprk1%20(2).jpg)
![](back_images/rk1%20(9).jpg)



